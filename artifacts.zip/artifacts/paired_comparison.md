| first | second | mean_iou_difference | ci_low | ci_high | matched_seeds | images_per_seed | ci_excludes_zero |
|---|---|---|---|---|---|---|---|
| baseline | augmented | 0.0271 | 0.0086 | 0.0446 | 3 | 34 | True |
| augmented | advanced | 0.0088 | -0.0023 | 0.0199 | 3 | 34 | False |
| augmented | advanced_ablation | -0.0022 | -0.0098 | 0.0017 | 3 | 34 | False |
| augmented | strong_aug | -0.0005 | -0.0148 | 0.0135 | 3 | 34 | False |
| strong_aug | distract | -0.0021 | -0.0138 | 0.0096 | 3 | 34 | False |
| strong_aug | resnet34 | 0.0736 | 0.0500 | 0.0982 | 3 | 34 | True |
| resnet34 | resnet34_distract | 0.0008 | -0.0109 | 0.0137 | 3 | 34 | False |
| resnet34 | deeplab_ft | 0.0078 | -0.0076 | 0.0261 | 3 | 34 | False |
